
from zhipuai import ZhipuAI
# 填写您自己的APIKey
client = ZhipuAI(api_key="18cd64bb597e2f78a0d28bd9f62370eb.j19XHsRz8KqXlqAx")


def quest(a, b):
    response = client.chat.completions.create(
        model="glm-3-turbo",  # 填写需要调用的模型名称
        messages=a+[
            {"role": "user", "content": b},
        ],
    )
    thisr = response.choices[0].message
    #print(thisr)
    return thisr.content, a+[{"role": "user", "content": b}]+[{"role": "assistant", "content": thisr.content}]
