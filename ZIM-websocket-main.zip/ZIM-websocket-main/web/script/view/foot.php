<audio src="/static/mp3/tcmnew.mp3" id="tcm"></audio>
<script>
    init()
</script>