<?php return array (
  'nick' => '1234',
  'password' => '81dc9bdb52d04dc20036dbd8313ed055',
  'llt' => 1717905185,
  'power' => 1,
  'rating' => 1500,
  'email' => 'wenku-renling@baidu.com',
  'about' => '',
  'dt' => 
  array (
  ),
  'addable' => 1,
);?>