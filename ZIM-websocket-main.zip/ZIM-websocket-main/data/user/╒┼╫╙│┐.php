<?php return array (
  'nick' => '张子晨',
  'password' => '5d89850c42fd66f7b6012826586f708c',
  'llt' => 1717904349,
  'power' => 1,
  'rating' => 1500,
  'email' => '15853306700@163.com',
  'about' => '',
  'dt' => 
  array (
  ),
  'addable' => 1,
);?>