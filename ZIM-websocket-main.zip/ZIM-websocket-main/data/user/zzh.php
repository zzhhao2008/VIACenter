<?php return array (
  'nick' => 'Dinner本尊',
  'password' => 'c7443f1c3584ab3407d5e5e735c869b4',
  'llt' => 1717904860,
  'power' => 1,
  'rating' => 1500,
  'email' => 'zzhhao2008@163.com',
  'about' => '',
  'dt' => 
  array (
  ),
  'addable' => 1,
);?>