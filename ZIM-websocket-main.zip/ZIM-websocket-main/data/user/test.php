<?php return array (
  'nick' => 'Nick',
  'password' => 'e10adc3949ba59abbe56e057f20f883e',
  'llt' => 1717904231,
  'power' => 1,
  'rating' => 1500,
  'email' => '123@114.com',
  'about' => '',
  'dt' => 
  array (
  ),
  'addable' => 1,
);?>