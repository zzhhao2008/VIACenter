<?php return array (
  'nick' => 'sb',
  'password' => '26148d621ef74844918af182d63976b6',
  'llt' => 1717905559,
  'power' => 1,
  'rating' => 1500,
  'email' => 'wxlkyxx1@163.com',
  'about' => '',
  'dt' => 
  array (
  ),
  'addable' => 1,
);?>