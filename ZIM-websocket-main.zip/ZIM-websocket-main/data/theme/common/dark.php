<?php

return array(
    "frontcolor"=>"#ddd",
    "backcolor"=>'url("/static/gif/1darkb.gif")',
    'activecolor'=>'#FFFF00',
    "barcolor"=>"#33445d",
    "barfcolor"=>"rgb(175, 164, 164)",
    "subbackcolor"=>"rgba(255, 255, 255, 0.2)"
);
