<?php

return array(
    "frontcolor"=>"#000",
    "backcolor"=>'rgb(239, 239, 239)',
    'activecolor'=>'#FFFF00',
    "barcolor"=>"#DDDDDD",
    "barfcolor"=>"rgb(35,35,35)",
    "subbackcolor"=>"rgba(205, 205, 205, 0.55)"
);
