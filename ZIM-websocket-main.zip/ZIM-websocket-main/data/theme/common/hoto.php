<?php

return array(
    "frontcolor"=>"#356",
    "backcolor"=>'url("/static/png/hotoback.jpg")',
    'activecolor'=>'#FFFF00',
    "barcolor"=>"rgb(45,85,95)",
    "barfcolor"=>"rgb(170, 225, 235)",
    "subbackcolor"=>"rgba(170, 225, 235, 0.55)"
);
