<?php return array (
  'theme' => 'dai',
  'selfset' => 
  array (
  ),
  'editortheme' => 'tomorrow',
);?>