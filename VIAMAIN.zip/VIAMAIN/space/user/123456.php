<?php return array (
  'nick' => '　　',
  'password' => 'e10adc3949ba59abbe56e057f20f883e',
  'llt' => 1716466703,
  'power' => 1,
  'rating' => 1500,
  'email' => '123456@1',
  'about' => '',
  'dt' => 
  array (
  ),
);?>