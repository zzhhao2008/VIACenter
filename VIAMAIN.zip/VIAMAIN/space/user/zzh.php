<?php return array (
  'nick' => '土豆🥔真菌',
  'password' => 'c7443f1c3584ab3407d5e5e735c869b4',
  'llt' => 1718530093,
  'power' => 10,
  'rating' => 1500,
  'email' => '',
  'about' => '',
  'dt' => 
  array (
  ),
  'name' => '土豆',
);?>