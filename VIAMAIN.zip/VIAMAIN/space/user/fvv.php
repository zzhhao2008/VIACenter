<?php return array (
  'nick' => 'fvv',
  'password' => '5d89850c42fd66f7b6012826586f708c',
  'llt' => 1716548418,
  'power' => 2,
  'rating' => 1500,
  'email' => '2637143663@qq.com',
  'about' => 'fvvfvv',
  'dt' => 
  array (
  ),
);?>