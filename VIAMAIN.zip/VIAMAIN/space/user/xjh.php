<?php return array (
  'nick' => '井盖',
  'password' => 'c04e56d2b514724c84baf2db13fd3a1e',
  'llt' => 1715350794,
  'power' => 10,
  'rating' => 1500,
  'email' => 'jinggai@mail.zsvstudio.top',
  'about' => '',
  'dt' => 
  array (
  ),
);?>