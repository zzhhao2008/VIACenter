<?php return array (
  'title' => '欢迎来到ZSV聚合多媒体',
  'content' => '1',
  'area' => 'multyplay',
  'time' => 1715426423,
  'author' => 'zzh',
);?>