<?php return array (
  'title' => '欢迎井盖同志正式入驻并接管航空板块主编！',
  'content' => 'ZSV AVI Center',
  'area' => 'avi',
  'time' => 1715426275,
  'author' => 'zzh',
);?>