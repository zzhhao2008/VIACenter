<?php return array (
  'title' => '痴',
  'content' => '痴痴痴',
  'area' => 'multyplay',
  'time' => 1718530362,
  'author' => 'zzh',
);?>