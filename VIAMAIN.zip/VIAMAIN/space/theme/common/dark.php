<?php

return array(
    "frontcolor"=>"#eee",
    "backcolor"=>'url("/static/png/galaxy-g.png")',
    'activecolor'=>'#FFFF00',
    "barcolor"=>"rgba(0,0,0,.5)",
    "barfcolor"=>"rgb(175,175,175)",
    "subbackcolor"=>"rgba(255, 255, 255, 0.15)"
);
