<div class="container footbar">
    <hr class="hr">
</div>
<style>
    .footbar {
        text-align: center;
        color: rgba(255,255,255,0.1);
    }

    .hr {
        border: 0;
        font-size: 12px;
        padding: 10px 0;
        position: relative;
        background: none;
    }

    .hr::before {
        content: "ZSV SPACE&AVI";
        position: absolute;
        padding: 0 10px;
        line-height: 1px;
        border: solid #fff;
        border-width: 0 100vw;
        white-space: nowrap;
        left: 50%;
        transform: translateX(-50%);
        color:#fff;
    }
</style>

<div class="reader" id="readerbox">
    <div id="pasreader" class="container main">

    </div>
</div>
<style>
    .reader {
        position: absolute;
        top: 60px;
        width: 100%;
        padding-top: 10px;
        background: rgba(0, 0, 0, 0.25);
        bottom: 0;
    }

    .reader>.main {
        background: rgba(0, 0, 0, 0.95);
        height: 100%;
        overflow-y: scroll;
    }
</style>
<script src='/static/js/markedjs.js'></script>
<script>
    reader = document.getElementById("pasreader");
    readerbox = document.getElementById("readerbox");
    readerbox.style.display = "none"

    function readPassage(bid) {
        readerbox.style.display = "block"

        var closebtn = document.createElement("button");
        closebtn.className = "btn btn-dark";
        closebtn.innerHTML = "X";
        closebtn.onclick = function() {
            readerbox.style.display = "none"
        };
        reader.appendChild(closebtn);
        fetch("/getpassage?bid=" + bid, {
                method: "GET",
            })
            .then(response => response.json())
            .then(data => {

                var titlebar = document.createElement("h4");
                titlebar.innerHTML = data.title;
                reader.appendChild(titlebar);

                var autherbar = document.createElement("span");
                autherbar.className = "badge rounded-pill";
                autherbar.innerHTML = data.author + "-" + data.time;
                reader.appendChild(autherbar);

                reader.appendChild(document.createElement("hr"));

                var body = document.createElement("div");
                body.innerHTML = marked.parse(data.content);
                reader.appendChild(body);

                reader.appendChild(document.createElement("hr"));
            })
    }
</script>