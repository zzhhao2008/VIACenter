<meta charset="UTF-8">
<link rel="shortcut icon" href="/icon.jpg">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
<link rel="stylesheet" href="/static/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/css/public.css">
<link rel="stylesheet" href="/static/css/tool.css">
<link rel="stylesheet" href="/static/bootstrap/icons/bootstrap-icons.css">
<script src="/static/bootstrap/5.3.2/js/bootstrap.bundle.js"></script>
<script src="/static/js/view.js"></script>
<script src="/static/js/src-min/ace.js"></script>
<script src="/static/js/aceinit.js"></script>
<script src="http://116.62.220.226/static/js/chart.js"></script>
<script src="/static/js/chart-require.js"></script>
<style>
    #<?=Router::getUri()?>naver{
        border-bottom: 2px solid red;
    }
    <?=theme::css();?>
</style>
