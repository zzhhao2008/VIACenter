<?php
class zymy{
    public $realname="";
    public $realname_English_upper="ZYMY";
    public $realname_English_lower="zymy";
    public $nickname="小土豆";
    public $nickname_English="potato";
    public $age=14;
    public $sex="女";
    function boom(){
        echo "你死了.不说了，生气了.再也不见";
    }
    public $status="活着";
    public $adj="可爱的";
    public $adj_English="cute";
}