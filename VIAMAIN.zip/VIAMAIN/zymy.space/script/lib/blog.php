<?php
class blog
{
    public $area = "";
    public $list = [];
    public $nowreading = "";
    public $stdcfg = [
        "title" => "", //标题，必填项，用于显示在列表中
        "time" => 0, //时间
        "author" => "", //作者ID，用于显示在列表中,必须
        "content" => "", //正文
        "area" => "" //分区
    ];
    public $stdlist = [
        [
            "title" => "", //标题，必填项，用于显示在列表中
            "time" => 0, //第一次的时间
            "author" => "", //第一次作者ID，用于显示在列表中,必须
            "dataid"=>0, //数据ID，用于读取详细信息，必须
        ]
    ];
    function init($area)
    {
        if (!in_array($area, ["space", "avi","multyplay"])) return -1;
        $this->area = $area;
        $this->list = DB::getdata("blog/$area.list");
        return count($this->list);
    }
    function readDetial($blogid)
    {
        $data = DB::getdata("blog/data/$blogid");
        if (!empty($data)) {
            $this->nowreading = $blogid;
            return $data;
        } else {
            $this->nowreading = "";
            return -1; //not found or error
        }
    }
    function saveChange($data, $blogid)
    {
        if (empty($data)) return -1; //not found or error
        if (empty($blogid)||$blogid==='new') {
            $blogid = count(DB::scanName("blog/data/")) + 1;
            $area = $data['area'];
            $list = DB::getdata("blog/$area.list");
            $list[] = [
                "title" => $data['title'], //标题，必填项，用于显示在列表中
                "time" => $data['time'], //时间
                "author" => $data['author'], //作者ID，用于显示在列表中,必须
                "dataid"=>$blogid,
            ];
            DB::putdata("blog/$area.list", $list);
        }
        DB::putdata("blog/data/$blogid", $data);
        return $blogid;
    }
}
