<?php
$bc=new blog();

if ($_GET['bid']) {
    $bid=$_GET['bid'];
    if($bid==='new'){
        $thisp=$bc->stdcfg;
    }else{
        $thisp=$bc->readDetial($bid);
    }
}

if ($_POST) {
    $blogdata=[
        "title"=>$_POST['title'],
        "content"=>$_POST['content'],
        "area"=>$_POST['area']?$_POST['area']:$thisp['area'],
        "time"=>time(),
        "author"=>user::read()['name'],
    ];
    if(empty($blogdata['title'])||empty($blogdata['area'])){
        view::alert("保存失败，标题和分区不能为空！","warning",100000);
    }else $newid=$bc->saveChange($blogdata,$bid);
    if($bid==='new'){
        jsjump("/blog_manage?bid=$newid");
        exit;
    }
    $thisp=$blogdata;
}
view::header("编辑blog-" . $bid);
if ($thisp<0) :
    echo "<h2>抱歉，该BLOG不存在或被禁止访问！</h2>";
else :
?>

    <form method="post" class="row" id="tableA">
        <div class="col-sm-8 problembox">
            <!--题面编辑-->
            <div>
                <div class="w-100">
                    <label for="tit" class="form-label">标题 <?=$bid?></label>
                    <input type="text" class="form-control" id="tit" name="title" value="<?= $thisp['title'] ?>">
                </div>
                <textarea id="pFace" class="form-control" rows="15" name="content"><?= $thisp['content'] ?></textarea>
                
            </div>
        </div>
        <div class="col-sm-4  problemsubbox">
            <div>
                <?php
                if($thisp['area']){
                    echo $thisp['area'];
                }else{
                ?>
                <label for="dft" class="form-label">分区*</label>
                <select class="form-select" id="dft" name="area">
                    <option value="avi">航空</option>
                    <option value="space">航天</option>
                    <option value="multyplay">多媒体</option>
                </select>
                <?}?>
            </div>
            <div>
                <input class="btn btn-primary" type="submit" value="保存">
                <button class="btn btn-danger" type="button" onclick="reflush()">重置</button>
            </div>
        </div>
    </form>

<?php endif;
view::foot(); ?>
<style>
    .problemFace {
        min-width: 100%;
        border: none;
        min-height: 500px;
        max-width: 100%;
    }
</style>
<script>
    function reflush() {
        res = prompt("确定重置更改请输入：yes")
        if (res == "yes") {
            document.getElementById('tableA').reset();
        }
    }
    document.addEventListener("keydown", function(e) {
        //可以判断是不是mac，如果是mac,ctrl变为花键
        //event.preventDefault() 方法阻止元素发生默认的行为。
        if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
            e.preventDefault();
            //document.getElementById("alertbox").innerHTML = "Ctrl+S保存成功！";
            document.getElementById("tableA").submit();
        }
    }, false);
</script>