<?php
view::header("加入我们-ZSPACE");
?>

<body>
    <div class="container main abox">
        <div id="about">

        </div>
        <?php

        $txt = <<<MD
<h3>联系我们</h3>
<h4>电子邮件</h4>
zzhhao2008@163.com<br/>
<h4>社交媒体</h4>
QQ:2019666136
WeChat:ZSV2022
MD;
        view::jsMdLt("about", $txt) ?>
    </div>
</body>
<?php
view::foot();
?>