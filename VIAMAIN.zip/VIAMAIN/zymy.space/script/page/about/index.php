<?php
view::header("关于我们-ZSPACE");
?>

<body>
    <div class="container main abox">
        <div id="about">

        </div>
        <?php

        $txt = <<<MD

<h3>主要版权信息</h3>

本站内主要图片来自以下源：
1. COMAC门户：http://www.comac.cc/
2. NASA :https://www.nasa.gov/

<h3>关于ZYMY.SPACE</h3>
<h4>ZYMY.SPACE是什么？</h4>
ZYMY.SPACE为 <a href='http://zsvstudio.top/'> ZSV Studio <a>旗下太空探索与航空技术门户，为各飞友提供航空航天相关集散服务。
同时，我们也提供多媒体聚合平台。
在这里，您可以看到众多创作者的精彩作品。
还等什么，立即加入！
<h4>为什么叫“ZYMY.SPACE"</h4>
不能说的秘密
<h3>联系我们</h3>
<h4>电子邮件</h4>
zzhhao2008@163.com<br/>
<h4>社交媒体</h4>
QQ:2019666136
WeChat:ZSV2022
MD;
        view::jsMdLt("about", $txt) ?>
    </div>
</body>
<?php
view::foot();
?>