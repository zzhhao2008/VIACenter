<?php
view::header("航天");
$blogc = new blog();
$bloglist = [];
if ($blogc->init("space") > 0) {
    $bloglist = $blogc->list;
} else {
    view::message("初始化失败", "出错了", "wrong");
}
$news = DB::getdata("sys/news");
?>

<body>
    <div class="container main">

        <div class="row">
            <div class="col-sm-12 problemsubbox">
                <div style="text-align: center;">
                    <h3>航天板块</h3>
                    主编：土豆真菌
                </div>
                <hr>
            </div>
            <div class="col-sm-8 problembox">
                <div id="defaultpage">
                    <h4>分区</h4>
                    <hr>
                    <div>
                        <?php foreach ($bloglist as $blog) { ?>
                            <div>
                                <h5><?= $blog['title'] ?></h5>
                                <span class="badge rounded-pill"><?= user::queryUserNick($blog['author'], 1, 1) ?></span>
                                <span class="badge rounded-pill bg-success"><?= getDate_ToNow($blog['time']) ?></span>
                                <button onclick="readPassage('<?= $blog['dataid'] ?>')" class="badge rounded-pill bg-danger">阅读</button>
                                <?php if (user::is_superuser()) : ?>
                                    <a class="badge rounded-pill bg-danger" href="/blog_manage?bid=<?= $blog['dataid'] ?>">编辑</a>
                                <?php endif; ?>
                                <hr>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>


            <div class="col-sm-4 problemsubbox">
                <div>
                    <h4>热点关注</h4>
                    数据来源：https://cannews.com.cn/
                    <hr>
                    <div>
                        <?php foreach ($news as $new) { ?>
                            <div class="news-item"><?= $new ?></div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php
view::foot();
?>