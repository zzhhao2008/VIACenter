<?php
$data=DB::getdata("blog/data/".$_GET['bid']);
$data['time']=getDate_ToNow($data['time']);
$data['author']=user::queryUserNick($data['author'],1,1);
echo json_encode($data,1);