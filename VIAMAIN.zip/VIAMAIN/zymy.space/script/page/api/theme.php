<?php
//var_dump($myThemeCfg);
echo theme::css();