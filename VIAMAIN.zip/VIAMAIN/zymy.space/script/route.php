<?php
Router::any("/", "index");
Router::any("visituser","user/visit");
Router::any("avi","avi/index");
Router::any("space","space/index");
Router::any("aboutus","about/index");
Router::any("multy","multyplay/index");
Router::any("getpassage","api/getpassage");
Router::any("DU","DU");

Router::login("profile", "user/profile");
Router::login("logup", "profile");
Router::login("change", "user/change");
Router::login("themeset","user/themeset");
Router::login("joinus","about/join");

Router::guest("practice", "user/login");
Router::guest("logup", "user/logup");


Router::admin("user_manage", "admin/user/manage");
Router::admin("user_edit", "admin/user/edit");
Router::admin("user_cr_rm", "admin/user/crm");
Router::admin("blog_manage", "admin/blog/change");
Router::admin("news_manage", "admin/sys/new");